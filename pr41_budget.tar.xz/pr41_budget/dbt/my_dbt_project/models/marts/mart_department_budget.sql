{{ config(materialized="table") }}

with dept as (
    select * from {{ ref("stg_departments") }}
),
project_spend as (
    select
        department_id,
        sum(project_budget) as sum_project_budgets
    from {{ ref("stg_projects") }}
    group by 1
),
payroll as (
    select
        department_id,
        sum(salary) as sum_employee_salaries
    from {{ ref("stg_employees") }}
    group by 1
)
select
    d.department_id,
    d.department_name,
    d.department_budget as planned_budget,
    coalesce(ps.sum_project_budgets, 0) as sum_project_budgets,
    coalesce(p.sum_employee_salaries, 0) as sum_employee_salaries,
    coalesce(ps.sum_project_budgets, 0) - d.department_budget as variance_projects_vs_plan,
    case
        when d.department_budget <> 0 then coalesce(ps.sum_project_budgets, 0) / d.department_budget
    end as projects_to_plan_ratio,
    case
        when d.department_budget <> 0 then coalesce(p.sum_employee_salaries, 0) / d.department_budget
    end as payroll_to_plan_ratio
from dept d
left join project_spend ps on d.department_id = ps.department_id
left join payroll p on d.department_id = p.department_id

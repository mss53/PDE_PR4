{{ config(materialized='view') }}

select
    project_id,
    project_name,
    project_budget as upcoming_project_budget,
    project_start_date,
    project_end_date,
    department_id,
    project_lead
from {{ source('raw_data', 'upcoming_projects') }}

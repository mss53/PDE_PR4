{{ config(materialized='view') }}

select
    project_id,
    project_name,
    project_budget as completed_project_budget,
    project_start_date,
    project_end_date,
    department_id
from {{ source('raw_data', 'completed_projects') }}

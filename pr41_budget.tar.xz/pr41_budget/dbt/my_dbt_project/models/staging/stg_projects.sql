select
    csv_row_index,
    project_id,
    project_name,
    project_budget,
    start_date,
    end_date,
    department_id
from {{ source('raw', 'projects') }}

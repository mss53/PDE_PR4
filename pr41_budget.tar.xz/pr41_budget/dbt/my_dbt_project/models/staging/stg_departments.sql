select
    department_id,
    department_name,
    department_budget,
    head_of_department,
    number_of_employees,
    department_goals,
    location
from {{ source('raw', 'departments') }}

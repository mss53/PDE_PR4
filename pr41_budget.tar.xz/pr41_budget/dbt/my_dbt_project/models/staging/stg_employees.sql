select
    employee_id,
    first_name,
    last_name,
    email,
    job_title,
    salary,
    hire_date,
    department_id
from {{ source('raw', 'employees') }}
